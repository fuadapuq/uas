import App from "."

export default function Page() {
  return <App />
}
